import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {

  let [count, setCount] = useState(10)

  const increaseValue = () => {
    if(count < 20){
      setCount(count + 1)
    }
  }

  const decreaseValue = () => {
    if(count > 0){
      setCount(count - 1)
    }
  }

  return (
    <>
      <h1>Couter App</h1>
      <h2>Countr Value: {count}</h2>
      <button onClick={increaseValue}>Increase Value</button>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <button onClick={decreaseValue}>Decrease Value</button>
    </>
  )
}

export default App
